import test from 'node:test';
import assert from 'node:assert/strict';
import lessons from '../src/data/lessons.json' with { type: 'json' };
import { validateLessonBank, evaluateAnswer, calculateExamResult } from '../src/core/lessons.mjs';

test('lesson bank contains a complete lesson and a quiz for every one of 72 source topics', () => {
  assert.equal(lessons.length, 72);
  assert.deepEqual(validateLessonBank(lessons), []);
  assert.ok(lessons.every(lesson => lesson.summary.length > 100));
  assert.ok(lessons.every(lesson => lesson.keyPoints.length >= 3));
  assert.ok(lessons.every(lesson => lesson.quiz.length >= 1));
});

test('answer evaluation distinguishes correct and incorrect choices', () => {
  const question = { correctIndex: 1, explanation: 'Пояснение' };
  assert.deepEqual(evaluateAnswer(question, 1), { correct: true, explanation: 'Пояснение', xp: 10 });
  assert.deepEqual(evaluateAnswer(question, 0), { correct: false, explanation: 'Пояснение', xp: 0 });
});

test('exam result counts correct answers and calculates percentage', () => {
  const questions = [{correctIndex:0},{correctIndex:2},{correctIndex:1},{correctIndex:1}];
  assert.deepEqual(calculateExamResult(questions, [0,2,0,1]), {total:4,correct:3,wrong:1,percent:75});
});

test('empty exam returns a safe zero result', () => {
  assert.deepEqual(calculateExamResult([], []), {total:0,correct:0,wrong:0,percent:0});
});

test('correct answer positions are distributed across choices', () => {
  const positions = new Set(lessons.map(lesson => lesson.quiz[0].correctIndex));
  assert.equal(positions.size, 4);
});
