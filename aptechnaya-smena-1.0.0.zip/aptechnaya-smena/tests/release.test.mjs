import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const app = await readFile(new URL('../src/main.jsx', import.meta.url), 'utf8');
const packageJson = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));

test('1.0 release keeps the game focused on shift, academy, practice and exam', () => {
  for (const label of ['Смена', 'Академия', 'Рецепты', 'Экзамен']) assert.ok(app.includes(label));
  assert.ok(app.includes('Четыре посетителя'));
  assert.ok(app.includes('История смены'));
});

test('1.0 release does not expose supplier, payroll or bookkeeping screens', () => {
  for (const legacyFeature of ['Предложение поставщика:', 'Поставка и касса', 'День кампании', 'получить {Math.max(0,1000']) {
    assert.ok(!app.includes(legacyFeature), `Unexpected legacy UI: ${legacyFeature}`);
  }
});

test('package version is the compact 1.0.0 release', () => {
  assert.equal(packageJson.version, '1.0.0');
});
