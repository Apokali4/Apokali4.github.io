import test from 'node:test';
import assert from 'node:assert/strict';
import syllabus from '../src/data/syllabus.json' with { type: 'json' };
import practice from '../src/data/practice.json' with { type: 'json' };
import { validatePracticeBank, checkPracticeAnswer, calculatePracticeScore } from '../src/core/practice.mjs';

test('practice bank preserves all 37 source tasks in original order and wording', () => {
  assert.equal(practice.length, 37);
  assert.deepEqual(validatePracticeBank(practice, syllabus.practical), []);
  assert.deepEqual(practice.map(item => item.sourceText), syllabus.practical.map(item => item.source_text));
});

test('practice answer checks dosage form and route without changing source prescription', () => {
  const task = practice[0];
  assert.deepEqual(checkPracticeAnswer(task, { form: 'solution', route: 'topical' }), {
    correct: true, formCorrect: true, routeCorrect: true, xp: 10
  });
  assert.deepEqual(checkPracticeAnswer(task, { form: 'tablet', route: 'oral' }), {
    correct: false, formCorrect: false, routeCorrect: false, xp: 0
  });
});

test('controlled and OCR-ambiguous tasks are visibly marked for human verification', () => {
  assert.equal(practice.find(item => item.id === 'P12').specialHandling, true);
  assert.equal(practice.find(item => item.id === 'P13').specialHandling, true);
  assert.equal(practice.find(item => item.id === 'P35').needsReview, true);
});

test('practice score handles completed and empty sessions', () => {
  assert.deepEqual(calculatePracticeScore([true, false, true]), { total: 3, correct: 2, wrong: 1, percent: 67 });
  assert.deepEqual(calculatePracticeScore([]), { total: 0, correct: 0, wrong: 0, percent: 0 });
});

test('practice awards XP once for the first correct completion and allows retry after a mistake', async () => {
  const { recordPracticeResult } = await import('../src/core/practice.mjs');
  const initial = { xp: 0, practiceDone: [], practiceAwarded: [] };
  const wrong = recordPracticeResult(initial, 'P01', { correct: false, xp: 0 });
  assert.equal(wrong.xp, 0);
  const firstCorrect = recordPracticeResult(wrong, 'P01', { correct: true, xp: 10 });
  assert.equal(firstCorrect.xp, 10);
  const repeated = recordPracticeResult(firstCorrect, 'P01', { correct: true, xp: 10 });
  assert.equal(repeated.xp, 10);
});

test('special administration routes remain distinct in the practice key', () => {
  const routeOf = id => practice.find(item => item.id === id).route;
  assert.equal(routeOf('P15'), 'ophthalmic');
  assert.equal(routeOf('P23'), 'inhalation');
  assert.equal(routeOf('P25'), 'rectal');
  assert.equal(routeOf('P26'), 'sublingual');
  assert.equal(routeOf('P28'), 'intravenous');
  assert.equal(routeOf('P33'), 'vaginal');
});
