import test from 'node:test';
import assert from 'node:assert/strict';
import { createGameplayState, enterZone } from '../src/core/gameplay.mjs';

test('gameplay starts in the sales floor and restores only a known room', () => {
  assert.equal(createGameplayState().zone, 'sales-floor');
  assert.equal(createGameplayState({ zone: 'unknown', inventory: ['legacy'] }).zone, 'sales-floor');
  assert.equal(createGameplayState({ zone: 'back-room' }).zone, 'back-room');
});

test('the door connects the sales floor and back room in both directions', () => {
  const backRoom = enterZone(createGameplayState(), 'back-room');
  assert.equal(backRoom.zone, 'back-room');
  assert.equal(enterZone(backRoom, 'sales-floor').zone, 'sales-floor');
  assert.equal(enterZone(backRoom, 'street').zone, 'back-room');
});
