import test from 'node:test';
import assert from 'node:assert/strict';
import { answerQuestion, getDueItems, calculateLevel, reviewTopic } from '../src/core/progression.mjs';

test('correct answer awards XP and marks the answer correct', () => {
  const result = answerQuestion({ xp: 0, correct: 0, wrong: 0 }, true);
  assert.deepEqual(result, { xp: 10, correct: 1, wrong: 0 });
});

test('wrong answer does not award XP and increments wrong count', () => {
  const result = answerQuestion({ xp: 10, correct: 1, wrong: 0 }, false);
  assert.deepEqual(result, { xp: 10, correct: 1, wrong: 1 });
});

test('review queue returns only items due at or before now', () => {
  const now = '2026-11-20T12:00:00.000Z';
  const items = [
    { id: 'a', dueAt: '2026-11-20T11:00:00.000Z' },
    { id: 'b', dueAt: '2026-11-21T11:00:00.000Z' },
    { id: 'c', dueAt: '2026-11-20T12:00:00.000Z' }
  ];
  assert.deepEqual(getDueItems(items, now).map(x => x.id), ['a', 'c']);
});

test('level grows every 100 XP and starts at level one', () => {
  assert.equal(calculateLevel(0), 1);
  assert.equal(calculateLevel(99), 1);
  assert.equal(calculateLevel(100), 2);
  assert.equal(calculateLevel(250), 3);
});

test('self-rating as known records topic and schedules next review', () => {
  const now = new Date('2026-11-20T12:00:00.000Z');
  const result = reviewTopic({ xp: 0, studied: [], reviews: {} }, 'T01', 'know', now);
  assert.equal(result.xp, 5);
  assert.deepEqual(result.studied, ['T01']);
  assert.equal(result.reviews.T01.streak, 1);
  assert.equal(result.reviews.T01.dueAt, '2026-11-21T12:00:00.000Z');
});

test('self-rating as repeat resets streak and schedules immediate review', () => {
  const now = new Date('2026-11-20T12:00:00.000Z');
  const result = reviewTopic({ xp: 5, studied: ['T01'], reviews: { T01: { streak: 3 } } }, 'T01', 'repeat', now);
  assert.equal(result.xp, 5);
  assert.equal(result.reviews.T01.streak, 0);
  assert.equal(result.reviews.T01.dueAt, now.toISOString());
});
