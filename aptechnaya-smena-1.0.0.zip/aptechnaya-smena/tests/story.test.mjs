import test from 'node:test';
import assert from 'node:assert/strict';
import { visitors, getCurrentVisitor, checkVisitorDecision, recordVisitorDecision } from '../src/core/story.mjs';

test('story contains a complete four-visitor training shift with unique ids', () => {
  assert.equal(visitors.length, 4);
  assert.equal(new Set(visitors.map(visitor => visitor.id)).size, visitors.length);
  assert.equal(getCurrentVisitor({ storyIndex: 0 }), visitors[0]);
  assert.equal(getCurrentVisitor({ storyIndex: 4 }), null);
});

test('each visitor has one safe best response and a meaningful explanation', () => {
  for (const visitor of visitors) {
    assert.equal(visitor.choices.filter(choice => choice.id === visitor.correctChoice).length, 1);
    const result = checkVisitorDecision(visitor, visitor.correctChoice);
    assert.equal(result.correct, true);
    assert.ok(result.feedback.length > 20);
    assert.equal(result.xp, 15);
  }
});

test('unsafe or overconfident responses do not award experience', () => {
  const visitor = visitors[0];
  const wrong = visitor.choices.find(choice => choice.id !== visitor.correctChoice);
  assert.equal(checkVisitorDecision(visitor, wrong.id).xp, 0);
});

test('visitor rewards are awarded once, and progress is retained', () => {
  const initial = { xp: 20, storyCompleted: [], storyAwarded: [], correct: 0, wrong: 0 };
  const result = checkVisitorDecision(visitors[0], visitors[0].correctChoice);
  const first = recordVisitorDecision(initial, visitors[0].id, result);
  const repeat = recordVisitorDecision(first, visitors[0].id, result);
  assert.equal(first.xp, 35);
  assert.equal(repeat.xp, 35);
  assert.deepEqual(repeat.storyCompleted, [visitors[0].id]);
});
