import test from 'node:test';
import assert from 'node:assert/strict';
import { clampPlayer, isNearVisitor, moveToward } from '../src/core/pharmacy-floor.mjs';

test('player remains inside the walkable pharmacy area', () => {
  assert.deepEqual(clampPlayer({x:-20,y:900},{width:900,height:330}), {x:24,y:306});
});

test('visitor interaction is available only within the interaction radius', () => {
  assert.equal(isNearVisitor({x:100,y:100},{x:145,y:100},48), true);
  assert.equal(isNearVisitor({x:100,y:100},{x:151,y:100},48), false);
});

test('tap movement advances toward a destination without overshooting', () => {
  assert.deepEqual(moveToward({x:0,y:0},{x:10,y:0},4), {x:4,y:0});
  assert.deepEqual(moveToward({x:8,y:0},{x:10,y:0},4), {x:10,y:0});
});
