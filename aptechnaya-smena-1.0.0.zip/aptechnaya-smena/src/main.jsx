import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import Phaser from 'phaser';
import syllabus from './data/syllabus.json';
import lessons from './data/lessons.json';
import practiceBank from './data/practice.json';
import { evaluateAnswer, calculateExamResult } from './core/lessons.mjs';
import { calculateLevel, reviewTopic, getDueItems } from './core/progression.mjs';
import { checkPracticeAnswer, recordPracticeResult } from './core/practice.mjs';
import { visitors, getCurrentVisitor, checkVisitorDecision, recordVisitorDecision } from './core/story.mjs';
import { clampPlayer, isNearVisitor, moveToward } from './core/pharmacy-floor.mjs';
import { createGameplayState, enterZone } from './core/gameplay.mjs';
import './style.css';

const FORM_OPTIONS = [
  ['solution','Раствор'],['tablet','Таблетки'],['powder','Порошок'],['ointment','Мазь'],['capsule','Капсулы'],['suspension','Суспензия'],['tincture','Настойка'],['injection_solution','Раствор для инъекций'],['transdermal_patch','ТТС / пластырь'],['eye_drops','Глазные капли'],['inhalation_solution','Раствор для ингаляций'],['aerosol','Аэрозоль'],['suppository','Суппозитории']
];
const ROUTE_OPTIONS = [
  ['topical','Наружно / местно'],['oral','Внутрь'],['intramuscular','Внутримышечно'],['transdermal','Трансдермально'],['ophthalmic','В глаза'],['inhalation','Ингаляционно'],['parenteral','Парентерально'],['injection_unspecified','Инъекционный путь не уточнён'],['intravenous','Внутривенно'],['rectal','Ректально'],['sublingual','Под язык'],['vaginal','Вагинально']
];

function PharmacyScene({ onSelectVisitor, activeVisitorId, zone, onZoneChange }) {
  const host = React.useRef(null);
  const selectRef = React.useRef(onSelectVisitor);
  const zoneRef = React.useRef(onZoneChange);
  React.useEffect(() => { zoneRef.current = onZoneChange; }, [onZoneChange]);
  React.useEffect(() => { selectRef.current = onSelectVisitor; }, [onSelectVisitor]);
  React.useEffect(() => {
    if (!host.current) return;
    class StoreScene extends Phaser.Scene {
      create() {
        const w = 900, h = 330;
        this.cameras.main.setBackgroundColor('#d8eee8');
        const g = this.add.graphics();
        g.fillStyle(0xe7f0df).fillRect(0,0,w,h);
        g.fillStyle(0xc9d9c7).fillRect(0,0,w,42);
        g.fillStyle(0x9ebeb0).fillRect(0,40,w,7);
        // Shelves, counter and floor tiles.
        for (let x=28; x<330; x+=74) {
          g.fillStyle(0xb78c65).fillRoundedRect(x,66,58,100,5);
          g.fillStyle(0xf4e8c8).fillRect(x+5,73,48,8);
          for(let y=91;y<151;y+=20){g.fillStyle([0x67b8a1,0xe2b56e,0x9b8bd0][Math.floor(y/20)%3]).fillRect(x+8,y,13,14);g.fillStyle(0xe7f2e8).fillRect(x+27,y,19,14);}
        }
        g.fillStyle(0x8b6c58).fillRoundedRect(355,72,510,45,8);
        g.fillStyle(0xe8d3a9).fillRoundedRect(363,79,494,30,5);
        g.fillStyle(0x8b6c58).fillRoundedRect(340,220,530,52,8);
        g.fillStyle(0xb7d7c9).fillRoundedRect(350,228,510,34,5);
        g.lineStyle(2,0xc3d8c9,0.8);
        for(let x=0;x<w;x+=50){g.lineBetween(x,180,x,330)}
        for(let y=180;y<h;y+=50){g.lineBetween(0,y,w,y)}
        this.add.text(450,15,zone==='back-room'?'АПТЕКА · ПОДСОБКА':'АПТЕКА · ТОРГОВЫЙ ЗАЛ',{fontFamily:'monospace',fontSize:'17px',color:'#356c62',fontStyle:'bold'}).setOrigin(.5);
        this.add.text(175,180,'СТЕЛЛАЖИ',{fontFamily:'monospace',fontSize:'11px',color:'#638476'}).setOrigin(.5);
        this.add.text(610,287,'КАССА',{fontFamily:'monospace',fontSize:'12px',color:'#53786d'}).setOrigin(.5);
        this.door=this.add.rectangle(865,190,38,74,0x9a7556).setStrokeStyle(3,0x6f503d).setInteractive({useHandCursor:true});
        this.add.text(865,145,zone==='back-room'?'В ЗАЛ':'ПОДСОБКА',{fontFamily:'monospace',fontSize:'9px',color:'#53786d'}).setOrigin(.5);
        this.door.on('pointerdown',()=>{if(Math.hypot(this.player.x-865,this.player.y-190)<85){this.tweens.add({targets:this.door,scaleX:.15,duration:180,yoyo:true,onComplete:()=>zoneRef.current?.(zone==='sales-floor'?'back-room':'sales-floor')});}else{this.target={x:825,y:235};this.hint.setText('Подойди к двери, чтобы перейти в подсобку.');}});
        const spots=[{id:'visitor-antibiotic',x:430,y:165,emoji:'👩🏻‍👦',name:'Марина'},{id:'visitor-missed-dose',x:555,y:165,emoji:'🧔🏻',name:'Игорь'},{id:'visitor-emergency',x:690,y:165,emoji:'😰',name:'Виктория'},{id:'visitor-large-print',x:800,y:165,emoji:'👵🏻',name:'Анна Петровна'}];
        this.visitorSprites=spots.map((spot,i)=>{
          const shadow=this.add.ellipse(spot.x,spot.y+22,45,12,0x719080,0.25);
          const body=this.add.circle(spot.x,spot.y,19,[0xf3d9c1,0xd5c5ad,0xf2c4b7,0xe3d4b9][i]).setStrokeStyle(2,0x8b9e8e);
          const face=this.add.text(spot.x,spot.y-3,spot.emoji,{fontSize:'25px'}).setOrigin(.5);
          const label=this.add.text(spot.x,spot.y+34,spot.name,{fontFamily:'monospace',fontSize:'10px',color:'#315c51',backgroundColor:'#f7f7e8',padding:{x:4,y:2}}).setOrigin(.5);
          const hit=this.add.zone(spot.x,spot.y,58,68).setInteractive({useHandCursor:true});
          hit.on('pointerdown',()=>this.chooseVisitor(spot));
          this.tweens.add({targets:[body,face],y:'-=3',duration:650+ i*100,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});
          return {...spot,shadow,body,face,label,hit};
        });
        if(zone==='back-room'){
          this.visitorSprites.forEach(visitor=>{visitor.body.setVisible(false);visitor.face.setVisible(false);visitor.label.setVisible(false);visitor.hit.disableInteractive();});
          g.fillStyle(0xc8b89c).fillRoundedRect(110,95,250,105,8);
          g.fillStyle(0xe9ddc4).fillRoundedRect(120,105,230,85,5);
          for(let i=0;i<5;i++){g.fillStyle([0x8eb5a4,0xd6a76c,0xa28acb][i%3]).fillRoundedRect(135+i*40,125,30,38,3);}
          this.add.text(235,80,'СТОЛ ПРОВЕРКИ ПОСТАВКИ',{fontFamily:'monospace',fontSize:'11px',color:'#5c6b55'}).setOrigin(.5);
          this.add.text(590,150,'📦  📦  📦',{fontSize:'30px'}).setOrigin(.5);
          this.add.text(590,180,'СКЛАДСКИЕ КОРОБКИ',{fontFamily:'monospace',fontSize:'10px',color:'#5c6b55'}).setOrigin(.5);
        }
        this.player=this.add.container(385,285,[this.add.ellipse(0,16,28,8,0x536c5d,0.3),this.add.circle(0,0,13,0x6b82c7).setStrokeStyle(2,0x344c8c),this.add.text(0,-2,'🧑🏻‍⚕️',{fontSize:'24px'}).setOrigin(.5)]);
        this.player.setDepth(10);
        this.walkBob=this.tweens.add({targets:this.player,y:'-=2',duration:120,yoyo:true,repeat:-1,paused:true,ease:'Sine.easeInOut'});
        this.target={x:385,y:285};
        this.cursors=this.input.keyboard.createCursorKeys();
        this.keys=this.input.keyboard.addKeys('W,A,S,D,SPACE');
        this.hint=this.add.text(450,310,'WASD / стрелки: ходить · тап по полу: идти · SPACE: поговорить',{fontFamily:'monospace',fontSize:'11px',color:'#315c51',backgroundColor:'#f8f8e8',padding:{x:8,y:4}}).setOrigin(.5);
        this.input.on('pointerdown',(pointer)=>{if(pointer.y>185 && pointer.y<325){this.target=clampPlayer({x:pointer.x,y:pointer.y},{width:w,height:h});}});
      }
      chooseVisitor(spot){
        if(!isNearVisitor({x:this.player.x,y:this.player.y},spot,62)){
          this.target={x:spot.x,y:spot.y+45};
          this.hint.setText(`Подхожу к посетителю: ${spot.name}…`);
          this.pendingVisitor=spot;
          return;
        }
        this.hint.setText(`Разговор: ${spot.name}`);
        selectRef.current?.(spot.id);
      }
      update(_,delta){
        const speed=delta*0.22;
        let dx=0,dy=0;
        if(this.cursors.left.isDown||this.keys.A.isDown)dx=-speed;
        if(this.cursors.right.isDown||this.keys.D.isDown)dx=speed;
        if(this.cursors.up.isDown||this.keys.W.isDown)dy=-speed;
        if(this.cursors.down.isDown||this.keys.S.isDown)dy=speed;
        if(dx||dy){this.target=clampPlayer({x:this.player.x+dx,y:this.player.y+dy},{width:900,height:330});}
        const next=moveToward({x:this.player.x,y:this.player.y},this.target,Math.max(1,speed));
        this.player.setPosition(next.x,next.y);
        if(Math.hypot(next.x-this.target.x,next.y-this.target.y)>1 || dx || dy){if(this.walkBob.isPaused())this.walkBob.resume();}else if(!this.walkBob.isPaused())this.walkBob.pause();
        if(this.pendingVisitor && isNearVisitor(next,this.pendingVisitor,62)){
          const visitor=this.pendingVisitor;this.pendingVisitor=null;this.chooseVisitor(visitor);
        }
        if(Phaser.Input.Keyboard.JustDown(this.keys.SPACE)){
          const nearest=this.visitorSprites.map(v=>({...v,distance:Math.hypot(v.x-next.x,v.y-next.y)})).sort((a,b)=>a.distance-b.distance)[0];
          if(nearest && nearest.distance<62)this.chooseVisitor(nearest);
          else this.hint.setText('Подойди ближе к посетителю, чтобы начать разговор.');
        }
      }
    }
    const game = new Phaser.Game({ type: Phaser.CANVAS, width:900, height:330, parent:host.current, backgroundColor:'#d8eee8', scene:[StoreScene], scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH}, render:{antialias:false,pixelArt:true} });
    return () => game.destroy(true);
  }, [zone]);
  return <div className="scene game-scene" ref={host} aria-label="Интерактивный торговый зал аптеки. Управление WASD или стрелками, нажмите на посетителя для разговора." />;
}
function App() {
  const [section,setSection] = useState('shift');
  const [topic,setTopic] = useState(syllabus.theory[0]);
  const [selectedAnswer,setSelectedAnswer] = useState(null);
  const [answerResult,setAnswerResult] = useState(null);
  const [examQuestions,setExamQuestions] = useState([]);
  const [examIndex,setExamIndex] = useState(0);
  const [examAnswers,setExamAnswers] = useState([]);
  const [examFinished,setExamFinished] = useState(false);
  const [topicSearch,setTopicSearch] = useState('');
  const [activePracticeId,setActivePracticeId] = useState(null);
  const [practiceForm,setPracticeForm] = useState('');
  const [practiceRoute,setPracticeRoute] = useState('');
  const [practiceResult,setPracticeResult] = useState(null);
  const [storyChoice,setStoryChoice] = useState('');
  const [storyResult,setStoryResult] = useState(null);
  const [progress,setProgress] = useState(() => {
    const empty = {xp:0,correct:0,wrong:0,studied:[],reviews:{},storyIndex:0,storyCompleted:[],storyAwarded:[],gameplay:createGameplayState(),};
    try {
      const stored = JSON.parse(localStorage.getItem('aptechka-progress'));
      return stored && typeof stored === 'object' ? {...empty,...stored,studied:Array.isArray(stored.studied)?stored.studied:[],reviews:stored.reviews ?? {},gameplay:createGameplayState(stored.gameplay)} : empty;
    } catch { return empty; }
  });
  const level = calculateLevel(progress.xp);
  const studiedCount = progress.studied.length;
  const dueTopics = useMemo(() => getDueItems(syllabus.theory.map(t => ({...t, dueAt: progress.reviews?.[t.id]?.dueAt ?? '2026-01-01T00:00:00.000Z'}))), [progress]);
  const reviewCard = (rating) => { const next = reviewTopic(progress, topic.id, rating); save(next); setSection('academy'); };
  const lesson = lessons.find(item => item.id === topic.id) ?? lessons[0];
  const quiz = lesson.quiz[0];
  const submitAnswer = () => {
    if (selectedAnswer === null || answerResult) return;
    const result = evaluateAnswer(quiz, selectedAnswer);
    setAnswerResult(result);
    const next = {...progress, xp: progress.xp + result.xp, correct: progress.correct + (result.correct ? 1 : 0), wrong: progress.wrong + (result.correct ? 0 : 1)};
    save(next);
  };
  const save = (next) => { setProgress(next); localStorage.setItem('aptechka-progress',JSON.stringify(next)); };
  const startStudy = (item) => { setTopic(item); setSelectedAnswer(null); setAnswerResult(null); setSection('lesson'); };
  const openPractice = (item) => {
    setActivePracticeId(item.id); setPracticeForm(''); setPracticeRoute(''); setPracticeResult(null); setSection('practice');
  };
  const activePractice = practiceBank.find(item => item.id === activePracticeId);
  const activeVisitor = getCurrentVisitor(progress);
  const gameplay = createGameplayState(progress.gameplay);
  const changeZone = (destination) => { const next = enterZone(gameplay,destination); save({...progress,gameplay:next}); };
  const selectSceneVisitor = (visitorId) => { const index = visitors.findIndex(v => v.id === visitorId); if(index < 0) return; save({...progress,storyIndex:index}); setStoryChoice(''); setStoryResult(null); setSection('shift'); };
  const submitPractice = () => {
    if (!activePractice || !practiceForm || !practiceRoute || practiceResult) return;
    const result = checkPracticeAnswer(activePractice, {form:practiceForm,route:practiceRoute});
    setPracticeResult(result);
    save(recordPracticeResult(progress, activePractice.id, result));
  };
  const submitStoryChoice = () => {
    if (!activeVisitor || !storyChoice || storyResult) return;
    const result = checkVisitorDecision(activeVisitor, storyChoice);
    setStoryResult(result);
    save(recordVisitorDecision(progress, activeVisitor.id, result));
  };
  const continueStory = () => {
    save({...progress,storyIndex:Math.min((progress.storyIndex ?? 0)+1,visitors.length)});
    setStoryChoice('');
    setStoryResult(null);
  };
  return <main className="app-shell">
    <header className="topbar"><div className="brand-mark">✚</div><div><div className="brand">АПТЕЧНАЯ <b>СМЕНА</b></div><small>Небольшая учебная RPG по фармакологии.</small></div><div className="profile"><span>⭐ {progress.xp} XP</span><span>Уровень {level}</span></div></header>
    <PharmacyScene onSelectVisitor={selectSceneVisitor} activeVisitorId={activeVisitor?.id} zone={gameplay.zone} onZoneChange={changeZone} />
    <section className="hero"><div><span className="eyebrow">ТВОЯ СМЕНА НАЧИНАЕТСЯ</span><h1>{section==='lesson' ? 'Новая тема!' : 'Добро пожаловать в аптеку!'}</h1><p>{section==='lesson' ? topic.title : 'Четыре посетителя, четыре учебные ситуации и никакой лишней бухгалтерии.'}</p></div><div className="hero-avatar">👩🏻‍⚕️</div></section>
    <nav className="tabs">
      { [['shift','Смена'],['academy','Академия'],['practice','Рецепты'],['exam','Экзамен']].map(([id,label])=><button key={id} className={section===id|| (section==='lesson'&&id==='academy')?'active':''} onClick={()=>setSection(id)}>{label}</button>)}
    </nav>
    {section==='shift' && <section className="panel compact-shift">
      <h2>☀️ Твоя учебная смена</h2>
      <div className="stats"><div><strong>{studiedCount}/72</strong><small>Тем изучено</small></div><div><strong>{progress.correct}</strong><small>Верных ответов</small></div><div><strong>{progress.practiceDone?.length ?? 0}/37</strong><small>Практических заданий</small></div></div>
      <div className="shift-quest"><div className="quest-avatar">👩🏻‍⚕️</div><div><b>Елена, старший фармацевт</b><p>«Выслушай посетителя, обрати внимание на опасные признаки. Не ставь диагноз и не угадывай препарат. Если ситуация вызывает сомнения, позови меня».</p></div></div>
      <div className="story-progress"><span>История смены</span><strong>{Math.min(progress.storyIndex ?? 0,visitors.length)} из {visitors.length} посетителей</strong><div><i style={{width:`${Math.min(100,((progress.storyIndex ?? 0)/visitors.length)*100)}%`}} /></div></div>
      {activeVisitor ? <div className="story-card"><div className="story-location">ПОСЕТИТЕЛЬ {Math.min((progress.storyIndex ?? 0)+1,visitors.length)} ИЗ {visitors.length}</div><div className="story-person"><span>{activeVisitor.avatar}</span><div><b>{activeVisitor.name}</b><small>{activeVisitor.role}</small></div></div><p className="story-dialogue">{activeVisitor.dialogue}</p><h3>{activeVisitor.prompt}</h3><div className="story-choices">{activeVisitor.choices.map(choice=><button key={choice.id} disabled={!!storyResult} className={'story-choice '+(storyChoice===choice.id?'selected':'')} onClick={()=>setStoryChoice(choice.id)}>{choice.text}</button>)}</div>{!storyResult && <button className="primary" disabled={!storyChoice} onClick={submitStoryChoice}>Ответить</button>}{storyResult && <div className={'feedback '+(storyResult.correct?'feedback-good':'feedback-bad')}><b>{storyResult.correct?'Верное решение · +15 XP':'Елена объясняет безопасный вариант'}</b><p>{storyResult.feedback}</p><button className="primary" onClick={continueStory}>{(progress.storyIndex ?? 0)+1===visitors.length?'Завершить историю':'Следующий посетитель'}</button></div>}</div> : <div className="story-finale"><div className="finale-icon">🌿</div><h3>Первая смена завершена!</h3><p>Ты разобрал(а) все четыре ситуации. Повтори сложные темы в Академии или закрепи знания практикой.</p><button className="primary" onClick={()=>{save({...progress,storyIndex:0});setStoryChoice('');setStoryResult(null);}}>Пройти историю ещё раз</button></div>}
      <button className="secondary" onClick={()=>{setTopic(dueTopics[0] ?? syllabus.theory[0]);setSection('lesson')}}>📖 Продолжить обучение</button>
      <p className="muted">Награда за каждую верную ситуацию начисляется только один раз. Учебные сценарии не заменяют консультацию специалиста.</p>
    </section>}
    {section==='academy' && <section className="panel"><h2>📚 Академия фармакологии</h2><p className="muted">72 темы из предоставленного экзаменационного списка.</p><input className="topic-search" value={topicSearch} onChange={e=>setTopicSearch(e.target.value)} placeholder="Найти тему или номер..."/><div className="topic-list">{syllabus.theory.filter(item=>`${item.number} ${item.title}`.toLowerCase().includes(topicSearch.toLowerCase())).map(item=><button key={item.id} className="topic" onClick={()=>startStudy(item)}><span className="topic-num">{item.number}</span><span>{item.title}</span><span>›</span></button>)}</div></section>}
    {section==='lesson' && <section className="panel">
      <div className="lesson-tag">ТЕМА {topic.number} ИЗ 72 · УЧЕБНЫЙ МОДУЛЬ</div>
      <h2>{topic.title}</h2>
      <div className="lesson-section"><h3>📖 Краткий конспект</h3><p>{lesson.summary}</p></div>
      <div className="lesson-section"><h3>🎯 Что нужно запомнить</h3><ul>{lesson.keyPoints.map((point,i)=><li key={i}>{point}</li>)}</ul></div>
      <div className="lesson-section"><h3>📚 Термины</h3><div className="terms">{lesson.terms.map(term=><span key={term}>{term}</span>)}</div></div>
      <div className="quiz-box"><div className="lesson-tag">ПРОВЕРЬ СЕБЯ</div><h3>{quiz.question}</h3>
        <div className="answers">{quiz.choices.map((choice,i)=><button key={i} disabled={!!answerResult} className={"answer "+(answerResult && i===quiz.correctIndex?"right":answerResult && i===selectedAnswer?"wrong":selectedAnswer===i?"chosen":"")} onClick={()=>setSelectedAnswer(i)}>{String.fromCharCode(65+i)}. {choice}</button>)}</div>
        {!answerResult && <button className="primary" disabled={selectedAnswer===null} onClick={submitAnswer}>Проверить ответ</button>}
        {answerResult && <div className={"feedback "+(answerResult.correct?"feedback-good":"feedback-bad")}><strong>{answerResult.correct?"Верно! +10 XP":"Пока неверно. Разберём."}</strong><p>{answerResult.explanation}</p><button className="primary" onClick={()=>{setSelectedAnswer(null);setAnswerResult(null);reviewCard(answerResult.correct?'know':'repeat')}}>Завершить урок</button></div>}
      </div>
      <div className="note">Учебный конспект для подготовки. Он не заменяет клинические рекомендации, официальные инструкции и действующие нормативные акты. Дозировки из практических заданий не являются назначениями пациентам.</div>
      <button className="secondary" onClick={()=>setSection('academy')}>Назад к темам</button>
    </section>}
    {section==='practice' && <section className="panel">
      <h2>🧾 Рецептурная лаборатория</h2>
      {!activePractice && <><p className="muted">37 практических заданий из исходного экзаменационного списка. Выбери задание, распознай лекарственную форму и путь применения.</p><div className="practice-progress"><strong>{progress.practiceDone?.length ?? 0} из 37</strong><span>заданий с сохранённой попыткой</span><div><i style={{width:`${((progress.practiceDone?.length ?? 0)/37)*100}%`}}/></div></div><div className="topic-list">{practiceBank.map(item=><button className="topic" key={item.id} onClick={()=>openPractice(item)}><span className="topic-num">{item.number}</span><span>{item.sourceText}<small className="practice-status">{item.specialHandling?'Требует особого контроля':item.needsReview?'Нужно сверить с оригиналом':progress.practiceDone?.includes(item.id)?'Попытка сохранена':'Учебное задание'}</small></span><span>›</span></button>)}</div></>}
      {activePractice && <>
        <button className="back-link" onClick={()=>{setActivePracticeId(null);setPracticeResult(null);}}>← К списку заданий</button>
        <div className="lesson-tag">ПРАКТИЧЕСКОЕ ЗАДАНИЕ {activePractice.number} ИЗ 37</div>
        <h3>Разбери назначение</h3>
        <div className="source-prescription"><small>ТЕКСТ ИЗ ИСХОДНОГО МАТЕРИАЛА, БЕЗ ИСПРАВЛЕНИЙ</small><p>{activePractice.sourceText}</p></div>
        {activePractice.specialHandling && <div className="safety-alert"><b>Особый контроль</b><p>В задании указан препарат со специальным правовым режимом или повышенными рисками. Здесь можно тренировать только распознавание формы и пути введения. Это не генератор рецепта и не инструкция по применению.</p></div>}
        {activePractice.needsReview && <div className="note"><b>Нужно сверить источник.</b> {activePractice.notice}</div>}
        {!activePractice.specialHandling && !activePractice.needsReview && <p className="muted">Определи форму препарата и путь его применения по исходной формулировке.</p>}
        <label className="field-label">Лекарственная форма</label><select className="practice-select" value={practiceForm} disabled={!!practiceResult} onChange={e=>setPracticeForm(e.target.value)}><option value="">Выбери форму...</option>{FORM_OPTIONS.map(([value,label])=><option key={value} value={value}>{label}</option>)}</select>
        <label className="field-label">Путь применения</label><select className="practice-select" value={practiceRoute} disabled={!!practiceResult} onChange={e=>setPracticeRoute(e.target.value)}><option value="">Выбери путь...</option>{ROUTE_OPTIONS.map(([value,label])=><option key={value} value={value}>{label}</option>)}</select>
        {!practiceResult && <button className="primary" disabled={!practiceForm||!practiceRoute} onClick={submitPractice}>Проверить разбор</button>}
        {practiceResult && <div className={"feedback "+(practiceResult.correct?'feedback-good':'feedback-bad')}><strong>{practiceResult.correct?'Верно! +10 XP':'Есть ошибки в разборе'}</strong><p>{practiceResult.formCorrect?'Форма определена верно.':`Форма: ${activePractice.formLabel}.`}</p><p>{practiceResult.routeCorrect?'Путь применения определён верно.':`Путь: ${activePractice.routeLabel}.`}</p><p className="source-warning">{activePractice.notice}</p><button className="primary" onClick={()=>{const next=practiceBank.find(item=>item.number>activePractice.number);if(next)openPractice(next);else{setActivePracticeId(null);setPracticeResult(null);}}}>Следующее задание</button></div>}
        <div className="note">Учебная классификация по тексту задания. Исходные назначения не проверены на клиническую корректность. Не используй их для лечения или оформления реальных рецептов.</div>
      </>}
    </section>}
    {section==='exam' && <section className="panel">
      <h2>🎓 Экзаменационный зал</h2>
      {!examQuestions.length && <><p>Проверка знаний по всем 72 темам. В случайной выборке 20 вопросов, по одному из разных разделов.</p><div className="stats"><div><strong>20</strong><small>Вопросов</small></div><div><strong>72</strong><small>Тем в базе</small></div><div><strong>10 XP</strong><small>За ответ</small></div></div><button className="primary" onClick={()=>{const pool=lessons.flatMap(l=>l.quiz.map(q=>({...q,topicId:l.id,topicNumber:l.number})));const shuffled=[...pool].sort(()=>Math.random()-.5).slice(0,20);setExamQuestions(shuffled);setExamIndex(0);setExamAnswers([]);setExamFinished(false);}}>▶ Начать экзамен</button></>}
      {!!examQuestions.length && !examFinished && <><div className="lesson-tag">ВОПРОС {examIndex+1} ИЗ {examQuestions.length}</div><div className="exam-progress"><div style={{width:`${(examIndex/examQuestions.length)*100}%`}}/></div><h3>{examQuestions[examIndex].question}</h3><div className="answers">{examQuestions[examIndex].choices.map((choice,i)=><button key={i} className={"answer "+(examAnswers[examIndex]===i?"chosen":"")} onClick={()=>setExamAnswers(a=>{const n=[...a];n[examIndex]=i;return n;})}>{String.fromCharCode(65+i)}. {choice}</button>)}</div><button className="primary" disabled={examAnswers[examIndex]===undefined} onClick={()=>{if(examIndex+1<examQuestions.length)setExamIndex(i=>i+1);else{const result=calculateExamResult(examQuestions,examAnswers);save({...progress,xp:progress.xp+result.correct*10,correct:progress.correct+result.correct,wrong:progress.wrong+result.wrong});setExamFinished(true);}}}> {examIndex+1===examQuestions.length?'Завершить экзамен':'Следующий вопрос'} </button></>}
      {!!examQuestions.length && examFinished && <><div className="exam-result"><strong>{calculateExamResult(examQuestions,examAnswers).percent}%</strong><span>Результат экзамена</span><p>Верных: {calculateExamResult(examQuestions,examAnswers).correct} · Ошибок: {calculateExamResult(examQuestions,examAnswers).wrong} · Всего: {examQuestions.length}</p></div><div className="topic-list">{examQuestions.map((q,i)=><div className="topic" key={q.id}><span className="topic-num">{i+1}</span><span><b>{examAnswers[i]===q.correctIndex?'Верно':'Ошибка'}.</b> {q.question}<br/><small>Правильный ответ: {q.choices[q.correctIndex]}</small></span></div>)}</div><button className="primary" onClick={()=>{setExamQuestions([]);setExamFinished(false);}}>Новый экзамен</button></>}
    </section>}
    <footer>АПТЕЧНАЯ СМЕНА · ОФЛАЙН-ПРОГРЕСС · ВЕРСИЯ 0.5.0</footer>
  </main>;
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
}
createRoot(document.getElementById('root')).render(<App />);
