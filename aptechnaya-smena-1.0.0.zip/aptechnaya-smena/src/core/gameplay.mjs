export const ZONES = {
  'sales-floor': { label: 'Торговый зал', exits: ['back-room'] },
  'back-room': { label: 'Подсобка', exits: ['sales-floor'] }
};

// The compact game only persists the current room. Inventory, supplier and payroll
// simulations were intentionally removed from the 1.0 scope.
export function createGameplayState(previous = {}) {
  return { zone: ZONES[previous.zone] ? previous.zone : 'sales-floor' };
}

export function enterZone(state, destination) {
  const current = ZONES[state.zone];
  if (!current?.exits.includes(destination)) return state;
  return { zone: destination };
}
