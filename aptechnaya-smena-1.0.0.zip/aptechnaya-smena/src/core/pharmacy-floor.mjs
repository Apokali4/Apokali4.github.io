export function clampPlayer(point, bounds, padding = 24) {
  return {
    x: Math.max(padding, Math.min(bounds.width - padding, point.x)),
    y: Math.max(padding, Math.min(bounds.height - padding, point.y))
  };
}

export function isNearVisitor(player, visitor, radius = 48) {
  return Math.hypot(player.x - visitor.x, player.y - visitor.y) <= radius;
}

export function moveToward(point, target, maxStep) {
  const dx = target.x - point.x;
  const dy = target.y - point.y;
  const distance = Math.hypot(dx, dy);
  if (!distance || distance <= maxStep) return { x: target.x, y: target.y };
  return { x: point.x + dx / distance * maxStep, y: point.y + dy / distance * maxStep };
}
