export function answerQuestion(progress, isCorrect) {
  return {
    xp: progress.xp + (isCorrect ? 10 : 0),
    correct: progress.correct + (isCorrect ? 1 : 0),
    wrong: progress.wrong + (isCorrect ? 0 : 1)
  };
}

export function getDueItems(items, now = new Date().toISOString()) {
  const cutoff = new Date(now).getTime();
  return items
    .filter(item => new Date(item.dueAt).getTime() <= cutoff)
    .sort((a, b) => new Date(a.dueAt) - new Date(b.dueAt));
}

export function calculateLevel(xp) {
  return Math.floor(Math.max(0, xp) / 100) + 1;
}

export function nextReviewDate(correctStreak, from = new Date()) {
  const intervals = [1, 3, 7, 14, 30];
  const days = intervals[Math.min(Math.max(correctStreak, 0), intervals.length - 1)];
  const date = new Date(from);
  date.setDate(date.getDate() + days);
  return date.toISOString();
}

export function reviewTopic(progress, topicId, rating, now = new Date()) {
  const current = progress.reviews?.[topicId] ?? { streak: 0, dueAt: now.toISOString() };
  const streak = rating === 'know' ? current.streak + 1 : 0;
  const days = rating === 'know' ? [1, 3, 7, 14, 30][Math.min(streak - 1, 4)] : 0;
  const due = new Date(now);
  due.setDate(due.getDate() + days);
  return {
    ...progress,
    xp: progress.xp + (rating === 'know' ? 5 : 0),
    studied: [...new Set([...(progress.studied ?? []), topicId])],
    reviews: { ...(progress.reviews ?? {}), [topicId]: { streak, dueAt: due.toISOString(), lastRating: rating } }
  };
}
