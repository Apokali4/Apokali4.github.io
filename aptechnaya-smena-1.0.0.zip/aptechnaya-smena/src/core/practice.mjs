export function validatePracticeBank(bank, sourceTasks) {
  const errors = [];
  if (!Array.isArray(bank) || !Array.isArray(sourceTasks)) return ['Банк практики должен быть массивом'];
  if (bank.length !== sourceTasks.length) errors.push(`Ожидалось ${sourceTasks.length} заданий, получено ${bank.length}`);
  const ids = new Set();
  bank.forEach((task, index) => {
    const source = sourceTasks[index];
    if (!task.id || ids.has(task.id)) errors.push(`Пустой или повторяющийся id: ${task.id}`);
    ids.add(task.id);
    if (!source || task.id !== source.id || task.sourceText !== source.source_text) errors.push(`${task.id}: исходный текст или порядок изменён`);
    if (!task.form || !task.formLabel || !task.route || !task.routeLabel) errors.push(`${task.id}: не указана форма или путь введения`);
    if (typeof task.specialHandling !== 'boolean' || typeof task.needsReview !== 'boolean') errors.push(`${task.id}: отсутствуют флаги безопасности/проверки`);
    if (!task.notice) errors.push(`${task.id}: отсутствует пояснение`);
  });
  return errors;
}

export function checkPracticeAnswer(task, answer) {
  const formCorrect = answer.form === task.form;
  const routeCorrect = answer.route === task.route;
  const correct = formCorrect && routeCorrect;
  return { correct, formCorrect, routeCorrect, xp: correct ? 10 : 0 };
}

export function calculatePracticeScore(results) {
  const total = results.length;
  const correct = results.filter(Boolean).length;
  return { total, correct, wrong: total - correct, percent: total ? Math.round(correct / total * 100) : 0 };
}

export function recordPracticeResult(progress, taskId, result) {
  const practiceDone = [...new Set([...(progress.practiceDone ?? []), taskId])];
  const practiceAwarded = [...(progress.practiceAwarded ?? [])];
  const earnsXp = result.correct && !practiceAwarded.includes(taskId);
  if (earnsXp) practiceAwarded.push(taskId);
  return {
    ...progress,
    xp: (progress.xp ?? 0) + (earnsXp ? result.xp : 0),
    practiceDone,
    practiceAwarded
  };
}
