export function validateLessonBank(lessons) {
  const errors = [];
  if (!Array.isArray(lessons)) return ['База уроков должна быть массивом'];
  if (lessons.length !== 72) errors.push(`Ожидалось 72 урока, получено ${lessons.length}`);
  const ids = new Set();
  for (const lesson of lessons) {
    if (!lesson.id || ids.has(lesson.id)) errors.push(`Пустой или повторяющийся id: ${lesson.id}`);
    ids.add(lesson.id);
    if (!lesson.summary || lesson.summary.length < 100) errors.push(`${lesson.id}: нет конспекта`);
    if (!Array.isArray(lesson.keyPoints) || lesson.keyPoints.length < 3) errors.push(`${lesson.id}: нужно 3 ключевых пункта`);
    if (!Array.isArray(lesson.terms) || lesson.terms.length < 2) errors.push(`${lesson.id}: недостаточно терминов`);
    if (!Array.isArray(lesson.quiz) || lesson.quiz.length < 1) errors.push(`${lesson.id}: нет контрольного вопроса`);
    for (const q of lesson.quiz ?? []) {
      if (!q.question || !Array.isArray(q.choices) || q.choices.length < 3 ||
          !Number.isInteger(q.correctIndex) || q.correctIndex < 0 || q.correctIndex >= q.choices.length ||
          !q.explanation) errors.push(`${lesson.id}: некорректный тест ${q.id}`);
    }
  }
  return errors;
}

export function evaluateAnswer(question, selectedIndex) {
  const correct = selectedIndex === question.correctIndex;
  return { correct, explanation: question.explanation, xp: correct ? 10 : 0 };
}

export function calculateExamResult(questions, answers) {
  const total = questions.length;
  const correct = questions.reduce((sum, question, index) =>
    sum + (answers[index] === question.correctIndex ? 1 : 0), 0);
  return { total, correct, wrong: total - correct, percent: total ? Math.round(correct / total * 100) : 0 };
}
